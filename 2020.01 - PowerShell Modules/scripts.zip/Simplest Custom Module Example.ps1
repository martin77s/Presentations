# *** Simplest Custom Module Example:


# set the modules root folder & name
$ModuleRoot = '$Home\Documents\WindowsPowerShell\Modules' # or $PSHOME\Modules (See $env:PSModulePath for discoverability)
$ModuleName = 'myFirstModule'


# create the module folder
New-Item -Path $ModuleRoot -Name $ModuleName -ItemType directory -Force


# create the module file contents (or just a ps1 file renamed to psm1)
'function HelloWorld { "HelloWorld!" }' | Out-File "$ModuleRoot\$ModuleName\$ModuleName.psm1"


# create the module manifest
New-ModuleManifest -Path "$ModuleRoot\$ModuleName\$ModuleName.psd1" -RootModule "$ModuleName.psm1"


# list the available modules with my* in their name
Get-Module -Name my* -ListAvailable  # <- this will list our new module if it's in any of the $env:PSModulePath folders


# explicitly import our new module
Import-Module -Name "$ModuleRoot\$ModuleName"


# run our HelloWorld function
HelloWorld


# remove the module
Remove-Module $ModuleName
