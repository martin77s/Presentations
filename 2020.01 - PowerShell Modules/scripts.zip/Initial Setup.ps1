#region Set some variables
$ModuleName = 'PSModulePipelineDemo'
$Path = 'C:\gitRepos'
$Author = 'Martin Schvartzman'
$Description = 'PowerShell module example',
$CompanyName = 'CONTOSO',
$AdoOrganization = 'maschvar'

$ModulePath = "C:\gitRepos\$ModuleName"
$RepoUrl = "https://$AdoOrganization@dev.azure.com/$AdoOrganization/$ModuleName/_git/$ModuleName"
#endregion


#region Clone the repo to a local folder
Set-Location -Path $Path
git.exe @('clone', $RepoUrl)
#endregion


#region Create the module directories
New-Item -ItemType Directory -Path $ModulePath\$ModuleName
New-Item -ItemType Directory -Path $ModulePath\$ModuleName\Private
New-Item -ItemType Directory -Path $ModulePath\$ModuleName\Public
New-Item -ItemType Directory -Path $ModulePath\$ModuleName\en-US # For about_Help files
New-Item -ItemType Directory -Path $ModulePath\Tests -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $ModulePath\Examples -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $ModulePath\Documentation -ErrorAction SilentlyContinue
#endregion


#region Create the module and related files
New-Item -ItemType File -Path "$ModulePath\$ModuleName\$ModuleName.Format.ps1xml"
New-Item -ItemType File -Path "$ModulePath\$ModuleName\en-US\about_$ModuleName.help.txt"
New-ModuleManifest -Path "$ModulePath\$ModuleName\$ModuleName.psd1" `
                   -RootModule "$ModuleName.psm1" `
                   -Description $Description `
                   -PowerShellVersion 5.1 `
                   -Author $Author `
				   -CompanyName $CompanyName `
                   -FormatsToProcess "$ModuleName.Format.ps1xml"
"# $ModuleName" | Out-File -FilePath "$ModulePath\README.md"
"# $ModuleName" | Out-File -FilePath "$ModulePath\Tests\index.md"
"# $ModuleName" | Out-File -FilePath "$ModulePath\Examples\index.md"
"# $ModuleName" | Out-File -FilePath "$ModulePath\Documentation\index.md"
New-Item -ItemType File -Path "$ModulePath\Tests\$ModuleName.Tests.ps1"
#endregion


#region Create the base module psm1 file
@'
$Public  = @( Get-ChildItem -Path $PSScriptRoot\Public\*.ps1 -ErrorAction SilentlyContinue )
$Private = @( Get-ChildItem -Path $PSScriptRoot\Private\*.ps1 -ErrorAction SilentlyContinue )
foreach($import in @($Public + $Private)) {
    try { . $import.fullname }
    catch { Write-Error -Message "Failed to import function $($import.fullname): $_" }
}
Export-ModuleMember -Function $Public.Basename
'@ | Out-File -FilePath "$ModulePath\$ModuleName\$ModuleName.psm1"
#endregion


#region Put some public/exported functions into the public folder, private functions into private folder
@'
function Get-TempFile {
    param([switch]$DontCreate)
    if($DontCreate) {
        Join-Path -Path ([System.IO.Path]::GetTempPath()) -ChildPath (
            'tmp{0}.tmp' -f (([System.Guid]::NewGuid().GUID) -replace '^(\w{4})(.*)', '$1')
        )
    } else { [System.IO.Path]::GetTempFileName() }
}
'@ | Out-File -FilePath "$ModulePath\$ModuleName\Private\Get-TempFile.ps1"

@'
function Get-LogFile {
    if(-not $Script:LogFile) {
        $Script:LogFile = Get-TempFile
    }
    if( -not (Test-Path -Path $Script:LogFile -ErrorAction SilentlyContinue)) {
        New-Item -Path $Script:LogFile -ItemType File -Force
    }
    $Script:LogFile
}
'@ | Out-File -FilePath "$ModulePath\$ModuleName\Private\Get-LogFile.ps1"

@'
function Write-Log {
    param($Message)
    Add-Content -Value ('{0:yyyy-MM-dd HH:mm:ss} - {1}' -f (Get-Date), $Message) -Path (Get-LogFile) -Force
}
'@ | Out-File -FilePath "$ModulePath\$ModuleName\Public\Write-Log.ps1"

@'
function Read-Log {
    Get-Content -Path (Get-LogFile)
}
'@ | Out-File -FilePath "$ModulePath\$ModuleName\Public\Read-Log.ps1"
#endregion


#region Push to the repository
Set-Location -Path $ModulePath
git.exe add .
git.exe commit -m 'content updates'
git push origin master
#endregion

