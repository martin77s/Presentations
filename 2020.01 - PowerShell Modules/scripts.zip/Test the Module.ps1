break


Get-PSRepository

$uri = 'https://mypsgallery.azurewebsites.net/nuget'
Register-PSRepository -Name myPSGallery -SourceLocation $uri -PublishLocation $uri -InstallationPolicy Trusted

Find-Module -Repository myPSGallery

Find-Module -Repository myPSGallery -Name PSModulePipelineDemo | fl
Save-Module -Repository myPSGallery -Name PSModulePipelineDemo -Path C:\Temp\1
# Install-Module ...